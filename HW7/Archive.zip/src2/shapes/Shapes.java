package shapes;

import java.awt.Color;

/**
 * Abstract class for all concrete Shapes objects.
 */
public abstract class Shapes {

  private double radius;
  private double height;
  private double width;
  private Color color;
  private double x;
  private double y;
  private String id;

  /**
   * Constructor for the shapes using width and height.
   *
   * @param hei   double for the height.
   * @param wid   double for the width.
   * @param red   int between 0 and 255 for red color.
   * @param green int between 0 and 255 for green color.
   * @param blue  int between 0 and 255 for blue color.
   * @param x     double for x position of shape.
   * @param y     double for y position of shape.
   */
  public Shapes(double hei, double wid, int red, int green, int blue, double x, double y, String id,
                int count) {
    if (green > 255 || green < 0 || red > 255 || red < 0 || blue > 255 || blue < 0) {
      throw new IllegalArgumentException("Red, blue, or green color index must be between 0 and "
              + "255!");
    } else if (hei < 0 || wid < 0) {
      throw new IllegalArgumentException("Shape can't have a negative height or width!");
    }
    this.width = wid;
    this.height = hei;
    this.color = new Color(red, green, blue);
    this.x = x;
    this.y = y;
    count++;
    this.id = id + count;
  }

  /**
   * Method to return the shapes personal id.
   *
   * @return String of object's id.
   */
  public String retID() {
    return this.id;
  }

  /**
   * Method to return shape's height.
   *
   * @return double of the shapes current height.
   */
  public double retHeight() {
    return this.height;
  }

  /**
   * Method to return the shape's width.
   *
   * @return double of the shape's current width.
   */
  public double retWidth() {
    return this.width;
  }

  /**
   * Method to return the shape's x coordinate.
   *
   * @return double of the shape's current x coordinate.
   */
  public double retX() {
    return this.x;
  }

  /**
   * Method to return the shape's y coordinate.
   *
   * @return double of the shape's current y coordinate.
   */
  public double retY() {
    return this.y;
  }

  /**
   * Method to return a shape's color.
   *
   * @return the actually color of the shape. Use built in get method to retrieve rgb values.
   */
  public Color retColor() {
    return this.color;
  }

}
