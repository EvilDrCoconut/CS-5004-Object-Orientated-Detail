package shapes;

/**
 * Interface for the abstract transformation class and concrete transformation classes: Resize,
 * Move, and Change Color. Included in model so that there will be a record of each change that was
 * made to an object that can be compared against the concrete Shape objects which hold data of
 * their original state.
 */
public interface Transformation {

  /**
   * Returns a statement of the shape object's initial properties relative to its current
   * properties.
   *
   * @return String statement showing the initial state and present state.
   */
  String getCurrentState();

  /**
   * Returns the Shape object of the Transformation object.
   *
   * @return
   */
  Shapes getShape();

  /**
   * Returns start time of Transformation object.
   *
   * @return Transformation start time
   */
  int getStartTime();

  /**
   * Returns end time of Transformation object.
   *
   * @return Transformation end time
   */
  int getEndTime();

  Type getType();
}
