package shapes;

/**
 * A class of type Transformation to resize a Shape object.
 */
public class Resize extends AbstractTransformation {
  private Shapes shape;
  private double width;
  private double height;
  private int tStart;
  private int tEnd;
  protected Type type;

  /**
   * Constructor for the Resize class.
   *
   * @param shape  shape object that is being transformed
   * @param width  new width of the shape
   * @param height new height of the shape
   * @param tStart start time of the resize
   * @param tEnd   end size of the resize
   */
  public Resize(Shapes shape, double width, double height, int tStart, int tEnd) {
    if (width < 0 || height < 0) {
      throw new IllegalArgumentException("Shape can't have a negative height or width!");
    }
    if (tStart < 0 || tEnd < 0) {
      throw new IllegalArgumentException("Time cannot be negative!");
    }
    if (tStart > tEnd) {
      throw new IllegalArgumentException("Start time cannot be after end time!");
    }
    this.shape = shape;
    this.width = width;
    this.height = height;
    this.tStart = tStart;
    this.tEnd = tEnd;
    this.type = Type.RESIZE;
  }

  @Override
  public String getCurrentState() {
    return String.format("%s scales from width %.1f and height %.1f to width %.1f and "
                    + "height %.1f from time %d to %d.\n", this.shape.retID(),
            this.shape.retWidth(), this.shape.retHeight(), this.width, this.height, this.tStart,
            this.tEnd);

  }

  public double getWidth() {
    return this.width;
  }

  public double getHeight() {
    return this.height;
  }

  public Type getType() {
    return this.type;
  }
}
