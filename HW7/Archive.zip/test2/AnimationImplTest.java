import shapes.Shapes;
import shapes.Rectangle;
import shapes.Oval;
import shapes.Move;
import shapes.Resize;
import shapes.ChangeColor;
import shapes.AnimationImpl;


import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Test class to ensure methods work as intended.
 */
public class AnimationImplTest {

  private Shapes oval;
  private Shapes rectangle;
  private Shapes oval2;
  private Shapes oval3;
  private Shapes rectangle2;

  // SHAPE OBJECT TESTS

  /**
   * Quick setup of some objects.
   */
  @Before
  public void setUp() {
    rectangle = new Rectangle(2, 3, 150, 33, 0, 100, 100);
    oval = new Oval(3, 1, 0, 57, 230, 250, 100);
    oval2 = new Oval(4, 2, 43, 67, 54, 52, 78);
    oval3 = new Oval(7, 5, 128, 210, 41, 250, 300);
    rectangle2 = new Rectangle(3, 6, 32, 240, 121, 50, -200);
  }

  /**
   * Test to show that a negative height and or width is not accepted.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testFirst() {
    Shapes rec = new Rectangle(-2, -3, 42, 43, 44, 111, 222);
    assertEquals(-2, rec.retHeight(), 0);
  }

  /**
   * Test to show a rgb under 0 or over 255 is not accepted.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testSecond() {
    Shapes ova = new Oval(3, 2, -34, 230, 260, 21, 34);
    assertEquals(21, ova.retX(), 0);
  }

  /**
   * Test to ensure widths are correctly set and updated.
   */
  @Test
  public void testThird() {
    assertEquals(3, rectangle.retWidth(), 0);
    assertEquals(1, oval.retWidth(), 0);
    assertEquals(2, oval2.retWidth(), 0);
    assertEquals(5, oval3.retWidth(), 0);
    assertEquals(6, rectangle2.retWidth(), 0);
  }

  /**
   * Test to show returning heights are correct.
   */
  @Test
  public void testFourth() {
    assertEquals(2, rectangle.retHeight(), 0);
    assertEquals(3, oval.retHeight(), 0);
    assertEquals(4, oval2.retHeight(), 0);
    assertEquals(7, oval3.retHeight(), 0);
    assertEquals(3, rectangle2.retHeight(), 0);
  }

  /**
   * Test to ensure id's are correct are correct.
   */
  @Test
  public void testFifth() {

    assertEquals("Oval 1", oval.retID());
    assertEquals("Oval 2", oval2.retID());
    assertEquals("Oval 3", oval3.retID());
    assertEquals("Rectangle 1", rectangle.retID());
    assertEquals("Rectangle 2", rectangle2.retID());
  }

  /**
   * Test to show returning x coordinates are correct.
   */
  @Test
  public void testSixth() {
    assertEquals(100, rectangle.retX(), 0);
    assertEquals(250, oval.retX(), 0);
    assertEquals(52, oval2.retX(), 0);
    assertEquals(250, oval3.retX(), 0);
    assertEquals(50, rectangle2.retX(), 0);
  }

  /**
   * Test to show returning y coordinates are correct.
   */
  @Test
  public void testSeventh() {
    assertEquals(100, rectangle.retY(), 0);
    assertEquals(100, oval.retY(), 0);
    assertEquals(78, oval2.retY(), 0);
    assertEquals(300, oval3.retY(), 0);
    assertEquals(-200, rectangle2.retY(), 0);
  }

  /**
   * Test to show returning colors are correct.
   */
  @Test
  public void testEighth() {
    assertEquals(150, rectangle.retColor().getRed(), 0);
    assertEquals(57, oval.retColor().getGreen(), 0);
    assertEquals(54, oval2.retColor().getBlue(), 0);
    assertEquals(128, oval3.retColor().getRed(), 0);
    assertEquals(240, rectangle2.retColor().getGreen(), 0);
  }

  // TRANSFORMATION OBJECT TESTS

  @Test(expected = IllegalArgumentException.class)
  public void testShapeMoveIllegalIllegalTime() {
    Move movedRect = new Move(rectangle, 3, 7, 8, 4);
  }

  @Test
  public void testShapeMove() {
    Move movedRect = new Move(rectangle, 3, 7, 0, 4);
    assertEquals(3, movedRect.getX(), .001);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShapeResizeIllegalWidth() {
    Resize resizedOval = new Resize(oval, -10, 15, 0, 4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShapeResizeIllegaHeight() {
    Resize resizedOval = new Resize(oval, 10, -15, 0, 4);
  }

  @Test
  public void testShapeResize() {
    Resize resizedOval = new Resize(oval, 10, 15, 0, 4);
    assertEquals(15, resizedOval.getHeight(), .001);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShapeChangeColorIllegalRed() {
    ChangeColor recoloredOval = new ChangeColor(oval, -1, 15, 0, 4,6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShapeChangeColorIllegalGreen() {
    ChangeColor recoloredOval = new ChangeColor(oval, 1, -15, 0, 4,6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShapeChangeColorIllegalBlue() {
    ChangeColor recoloredOval = new ChangeColor(oval, 1, 15, 256, 4,6);
  }

  @Test
  public void testShapeChangeColor() {
    ChangeColor resizedOval = new ChangeColor(oval, 50, 60, 70, 4, 14);
    assertEquals(60, resizedOval.getGreen(), .001);
  }

  // ANIMATION IMPL TESTS
  @Test
  public void testAddTransformation() {
    AnimationImpl tList = new AnimationImpl();
    tList.addTransformation(new Move(rectangle, 20, 20, 5, 10));
    tList.addTransformation(new Move(oval, 40, 20, 7, 13));
    tList.addTransformation(new Move(oval, 30, 30, 8, 17));
    tList.addTransformation(new Resize(rectangle, 20, 30, 100, 160));
    tList.addTransformation(new ChangeColor(oval, 0, 0, 255, 37, 42));

    assertEquals("Rectangle 1 moves from (100.0, 100.0) to (20.0, 20.0) from time 5 to 10.\n"
            + "Oval 1 moves from (250.0, 100.0) to (40.0, 20.0) from time 7 to 13.\n"
            + "Oval 1 moves from (250.0, 100.0) to (30.0, 30.0) from time 8 to 17.\n"
            + "Rectangle 1 scales from width 3.0 and height 2.0 to width 20.0 and height 30.0 from "
            + "time 100 to 160.\n"
            + "Oval 1 moves changes color from (0, 57, 230) to (0, 0, 255) from time 37 to 42.",
            tList.toString());
  }
}
