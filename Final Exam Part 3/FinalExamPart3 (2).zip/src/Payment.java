public interface Payment {

  void acceptPurchase(Order order);

}
