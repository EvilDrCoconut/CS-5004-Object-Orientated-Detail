
public interface PumpComponent {

  void accept(PumpComponentVisitor repairDrone);

}
