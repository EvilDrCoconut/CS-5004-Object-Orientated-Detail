package cs5004.animator.view;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

import cs5004.animator.controller.ControllerLayout;
import cs5004.animator.controller.midController;
import cs5004.animator.model.AnimationImpl;
import cs5004.animator.util.AnimationReader;

/**
 * Class that constructors command line argument parser to take input from user or file to render an
 * animation.
 */
public final class EasyAnimator {

  /**
   * Parses command line arguments from user or file.
   *
   * @param args command line arguments
   * @throws IOException if file is not found.
   */
  public static void main(String[] args) throws IOException {
    String in = "";
    String out = "";
    String view = "";
    String speed = "";
    int speedTicks = 0;
    int i;
    for (i = 0; i < args.length; i++) {
      switch (args[i]) {
        case "-in":
          in = args[i + 1];
          break;
        case "-out":
          out = args[i + 1];
          break;
        case "-view":
          view = args[i + 1];
          break;
        case "-speed":
          speed = args[i + 1];
          break;
        default:
          break;
      }
    }

    FileReader reader = new FileReader(in);
    AnimationImpl.Builder build = new AnimationImpl.Builder();
    AnimationImpl model = (AnimationImpl) AnimationReader.parseFile(reader, build);

    if (speed.equals("")) {
      speedTicks = 1;
    } else {
      speedTicks = Integer.parseInt(speed);
    }

    Views viewer = null;

    if (view.equals("")) {
      throw new IllegalArgumentException("Need a chosen view type from following options: text, "
              + "svg, or visual");
    } else {
      view = view.toLowerCase();
      switch (view) {
        case "svg":
          viewer = new SVGView(model, out);
          viewer.render();
          break;
        case "text":
          viewer = new TextView(model, out);
          viewer.render();
          break;
        case "visual":
          viewer = new VisualView(model, speedTicks);
          ControllerLayout middle = new midController(model, viewer);
          break;
        default:
          break;
      }
    }
  }

}

