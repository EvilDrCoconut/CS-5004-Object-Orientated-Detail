package cs5004.animator.view;

import java.io.IOException;
import java.util.Map;

import cs5004.animator.model.AnimationImpl;
import cs5004.animator.model.Shape;

/**
 * Interface for all types of views that will be displayed.
 */
public interface Views {

  void render() throws IOException;

  void render(Map<String, Shape> newMap);

  /**
   * Method to return the speed of the animation.
   *
   * @return int of the speed of animation.
   */
  int retSpeed();
}
