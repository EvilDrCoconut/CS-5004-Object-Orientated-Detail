package cs5004.animator.view;

import java.awt.*;
import java.io.IOException;
import java.util.Map;

import javax.swing.*;

import cs5004.animator.model.AnimationImpl;
import cs5004.animator.model.Shape;

public class VisualView extends JFrame implements Views {

  private MainPanel panel;
  private AnimationImpl model;
  private int speed;

  public VisualView(AnimationImpl model, int speed) {
    this.model = model;
    this.speed = speed;

    Map<String, Shape> shapes = model.retHashmap();

    JFrame frame = new JFrame("2D Animator!!!");
    frame.setSize(model.retCanvas().retWidth(), model.retCanvas().retHeight());
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.getContentPane().setBackground(Color.WHITE);

    panel = new MainPanel(model.retCanvas().retX(), model.retCanvas().retY());
    panel.mapGetter(model.retHashmap());

    frame.add(panel);
    frame.pack();
    frame.setVisible(true);
  }


  @Override
  public void render() throws IOException {
  }

  /**
   * Method to render the current frame of animation.
   *
   * @param newMap The current hash map of all shapes in the current frame.
   */
  public void render(Map<String, Shape> newMap) {
//    panel.redraw(newMap);
    int i;
    for (i = 6; i < 101; i++) {
      panel.animate(model.getShapesInFrame(i));
    }
  }

  /**
   * Method to return the speed of animation.
   *
   * @return int of the speed of the animation.
   */
  @Override
  public int retSpeed() {
    return speed;
  }
}