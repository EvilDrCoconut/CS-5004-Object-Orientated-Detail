package cs5004.animator.view;

import java.awt.*;
import java.util.Map;
import java.util.List;


import javax.swing.*;

import cs5004.animator.model.Shape;
import cs5004.animator.model.Type;

/**
 * Main panel class where the animation happens.
 */
public class MainPanel extends JPanel {

  private int canX;
  private int canY;
  private Map<String, Shape> helper;

  /**
   * Constructor for the main panel where everything is painted.
   *
   * @param canX int of where the farther left of the pane is.
   * @param canY int of where the highest upwards point is on the panel.
   */
  public MainPanel(int canX, int canY) {
    this.canX = canX;
    this.canY = canY;
  }

  /**
   * Helper Method to initialize first hashmap.
   *
   * @param map takes in the first hashmap created.
   */
  public void mapGetter(Map<String, Shape> map) {
    this.helper = map;
  }

  /**
   * Method to redraw the current frame and shapes.
   *
   * @param newMap the new hasmap of shapes to be drawn.
   */
  void redraw(Map<String, Shape> newMap) {
    this.helper = newMap;
    repaint();
  }
  void animate(List<Shape> shapeList) {
    int i;
    for (Shape each : shapeList) {
      for (i = each.getAppearanceTime(); i < each.getDisappearanceTime() + 1; i++) {
        repaint();
      }
    }
  }

  /**
   * Method to paint the current panel.
   *
   * @param g the graphics to be painted.
   */
  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;
    for (Map.Entry<String, Shape> entry : helper.entrySet()) {
      String k = entry.getKey();
      Shape v = entry.getValue();
      if (v.retType().equals("rectangle")) {
        g2d.setColor(new Color(v.retColor().getRed(),
                v.retColor().getGreen(),
                v.retColor().getBlue()));
        g2d.fillRect(v.retX() - this.canX,
                v.retY() - this.canY,
                v.retWidth(),
                v.retHeight());
      } else {
        g2d.setColor(new Color(v.retColor().getRed(),
                v.retColor().getGreen(),
                v.retColor().getBlue()));
        g2d.fillOval(v.retX() - this.canX,
                v.retY() - this.canY,
                v.retWidth(),
                v.retHeight());
      }
    }
  }
}