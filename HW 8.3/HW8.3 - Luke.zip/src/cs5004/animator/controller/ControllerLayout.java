package cs5004.animator.controller;

/**
 * Interface to tie all controllers under a common inheritance.
 */
public interface ControllerLayout {

}
