package cs5004.animator.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

import cs5004.animator.controller.*;
import cs5004.animator.model.Shape;
import cs5004.animator.model.AbstractShape;
import cs5004.animator.model.AnimationImpl;
import cs5004.animator.view.Views;

public class midController implements ControllerLayout{
  int currentFrame;
  Timer time;


  public midController(AnimationImpl model, Views viewer){

    time = new Timer(1000 / viewer.retSpeed(), new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent actionEvent) {

        Map<String, Shape> passer = new HashMap<String, Shape>();
        passer = model.getShapesInCurrentFrame(currentFrame, viewer.retSpeed());
        viewer.render(passer);
        currentFrame ++;
      }
    });

  }



}
