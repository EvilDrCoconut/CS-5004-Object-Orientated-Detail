package cs5004.animator.model;

import java.util.Comparator;

/**
 * Comparator to sort Transformation objects by end times.
 */
public class TimeComparator4 implements Comparator<Transformation> {
  public int compare(Transformation motion1, Transformation motion2) {
    if (motion1.getEndTime() == motion2.getEndTime()) {
      return 0;
    } else if (motion1.getEndTime() > motion2.getEndTime()) {
      return -1;
    } else {
      return 1;
    }
  }
}
