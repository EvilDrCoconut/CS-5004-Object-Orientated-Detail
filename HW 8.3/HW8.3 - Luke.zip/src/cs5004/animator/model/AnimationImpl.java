package cs5004.animator.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import cs5004.animator.util.AnimationBuilder;

/**
 * Class the employs an array list to house Transformations of Shape objects. Included in
 * cs5004.animator.model so that as the Shape objects change, there will be a record of what
 * transformations they underwent which can be printed in a string description.
 */
public class AnimationImpl implements Animation {
  private Canvas canvas;
  private HashMap<String, Shape> shapeMap;
  private List<Transformation> transformationList;
  private Map<AbstractShape, ArrayList<Shape>> allShapeStates;

  /**
   * Constructs beginning data structures for new Animation Implementation to house shape and
   * transformation object.
   */
  public AnimationImpl() {
    canvas = null;
    shapeMap = new HashMap<>();
    transformationList = new ArrayList<>();
    allShapeStates = new HashMap<>();
  }

  @Override
  public void addTransformation() {
    for (Map.Entry<String, Shape> each : shapeMap.entrySet()) {
      for (Transformation motion : each.getValue().getChanges()) {
        this.transformationList.add(motion);
      }
    }
    transformationList.sort(new TimeComparator());
  }

  @Override
  public int getFinalTime() {
    transformationList.sort(new TimeComparator4());
    for (int i = 0; i < transformationList.size(); i++) {
      if (i == transformationList.size() - 1) {
        return transformationList.get(i).getEndTime();
      }
    }
    throw new IllegalArgumentException("There is no previous transformation.");
  }

  @Override
  public void addCanvas(int x, int y, int width, int height) {
    this.canvas = new Canvas(x, y, width, height);
  }

  @Override
  public void addShape(String id, Shape shape) {
    this.shapeMap.put(id, shape);
  }

  @Override
  public Shape getShape(String id) {
    return this.shapeMap.get(id);
  }

  @Override
  public Transformation getTransformation(String id) {
    for (Transformation each : transformationList) {
      if (each.getName().equals(id)) {
        return each;
      }
    }
    throw new NoSuchElementException("Shape does not exist.");
  }

  @Override
  public void replace(String id, Shape shape) {
    shapeMap.replace(id, shape);
  }

  @Override
  public Canvas retCanvas() {
    return this.canvas;
  }

  @Override
  public List<Transformation> retList() {
    return transformationList;
  }

  @Override
  public List<Shape> getShapesInFrame(int frame) {
    List<Shape> frameList = new ArrayList<>();
    for (Map.Entry<String, Shape> each : this.shapeMap.entrySet()) {
      frameList.add(each.getValue().createFrame(frame));
    }
    return frameList;
  }

  @Override
  public Map<String, Shape> getShapesInCurrentFrame(int frame, int speed) {
//    Map<String, Shape> passer = new HashMap<String, Shape>();
//
//    for (Map.Entry<AbstractShape, ArrayList<Shape>> entry : allShapeStates.entrySet()) {
//      Shape k = entry.getKey();
//      List<Shape> v = entry.getValue();
//      if (k.getAppearanceTime() * speed <= frame && frame <= k.getDisappearanceTime() * speed) {
//        passer.putIfAbsent(k.retID(), k);
//      }
//
//      for (Shape shape : v) {
//        if (shape.getAppearanceTime() * speed <= frame && frame <= shape.getDisappearanceTime()
//                * speed) {
//          passer.putIfAbsent(shape.retID(), shape);
//        }
//      }
//    }
//    return passer;
    return null;
  }

  public HashMap<String, Shape> retHashmap() {
    return this.shapeMap;
  }

  @Override
  public String getState1() {
    String state = "";
    String initialState = "";
    String currentState = "";

    for (Map.Entry<String, Shape> one : shapeMap.entrySet()) {
      initialState += one.getValue().getAttributes();
    }

    addTransformation();

    for (Transformation each : transformationList) {
      currentState += each.getCurrentState();
    }

    state += initialState;
    state += currentState;

    return state.stripTrailing();
  }

  /**
   * Nested class used to parse data from input files in order to be fed into the Animation
   * implementation methods with the end result of producing an animation.
   */
  public static final class Builder implements AnimationBuilder<Animation> {

    Animation animation = new AnimationImpl();

    @Override
    public Animation build() {
      return animation;
    }

    @Override
    public AnimationBuilder<Animation> setBounds(int x, int y, int width, int height) {
      animation.addCanvas(x, y, width, height);
      return this;
    }

    @Override
    public AnimationBuilder<Animation> declareShape(String name, String type) {
      if (type.equals("rectangle")) {
        animation.addShape(name, new Rectangle(0, 0, 0, 0, 0, 0,
                0, name, "rectangle", 0));
      }
      if (type.equals("ellipse")) {
        animation.addShape(name, new Oval(0, 0, 0, 0, 0, 0, 0,
                name, "ellipse", 0));
      }
      return this;
    }

    @Override
    public AnimationBuilder<Animation> addMotion(String name, int t1, int x1, int y1, int w1,
                                                 int h1, int r1, int g1, int b1, int t2, int x2,
                                                 int y2, int w2, int h2, int r2, int g2, int b2) {

      if (w1 == 0 || w2 == 0 || h1 == 0 || h2 == 0) {
        throw new IllegalArgumentException("Shape cannot be dimensionless.");
      }

      HashMap<String, Shape> shapeMap = animation.retHashmap();
      Shape shape = shapeMap.get(name);

      boolean rectangle = shape.retType().equals("rectangle");
      boolean oval = shape.retType().equals("ellipse");

      boolean shapeMoves = (x1 != x2)
              || (y1 != y2);

      boolean shapeResizes = (w1 != w2)
              || (h1 != h2);

      boolean shapeRecolors = (r1 != r2)
              || (g1 != g2)
              || (b1 != b2);

      boolean shapePersists = (x1 == x2)
              && (y1 == y2)
              && (w1 == w2)
              && (h1 == h2)
              && (r1 == r2)
              && (g1 == g2)
              && (b1 == b2);

      if (rectangle) {
        if (shape.retHeight() == 0 || shape.retWidth() == 0) {
          shapeMap.replace(name, new Rectangle(h1, w1, r1, g1, b1, x1, y1, name,
                  "rectangle", t1));
        }
      } else if (oval) {
        if (shape.retHeight() == 0 || shape.retWidth() == 0) {
          shapeMap.replace(name, new Oval(h1, w1, r1, g1, b1, x1, y1, name,
                  "ellipse", t1));
        }
      }

      if (rectangle) {
        if (shapeMoves || shapePersists) {
          Transformation newMotion = new Move(name, Type.MOVE, Type.RECTANGLE, t1, x1, y1, w1, h1,
                  r1,
                  g1, b1,
                  t2, x2, y2, w2, h2, r2, g2, b2);
          shape.addMovement(newMotion);
        }
        if (shapeResizes) {
          Transformation newMotion = new Resize(name, Type.RESIZE, Type.RECTANGLE, t1, x1, y1, w1,
                  h1,
                  r1, g1,
                  b1, t2, x2, y2, w2, h2, r2, g2, b2);
          shape.addResize(newMotion);
        }
        if (shapeRecolors) {
          Transformation newMotion = new ChangeColor(name, Type.CHANGECOLOR, Type.RECTANGLE, t1,
                  x1, y1, w1,
                  h1, r1,
                  g1, b1, t2, x2, y2, w2, h2, r2, g2, b2);
          shape.addRecolor(newMotion);
        }
      }

      if (oval) {
        if (shapeMoves || shapePersists) {
          Transformation newMotion = new Move(name, Type.MOVE, Type.OVAL, t1, x1, y1, w1, h1, r1,
                  g1, b1,
                  t2, x2, y2, w2, h2, r2, g2, b2);
          shape.addMovement(newMotion);
        }
        if (shapeResizes) {
          Transformation newMotion = new Resize(name, Type.RESIZE, Type.OVAL, t1, x1, y1, w1, h1,
                  r1, g1, b1,
                  t2, x2, y2, w2, h2, r2, g2, b2);
          shape.addResize(newMotion);
        }
        if (shapeRecolors) {
          Transformation newMotion = new ChangeColor(name, Type.CHANGECOLOR, Type.OVAL, t1, x1,
                  y1, w1, h1, r1, g1, b1, t2, x2, y2, w2, h2, r2, g2, b2);
          shape.addRecolor(newMotion);
        }
      }
      return this;
    }
  }
}