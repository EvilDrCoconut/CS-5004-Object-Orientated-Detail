package cs5004.animator.model;

import java.util.Comparator;

/**
 * Comparator to sort Transformation start times and end times.
 */
public class TimeComparator implements Comparator<Transformation> {
  public int compare(Transformation motion1, Transformation motion2) {
    return Integer.compare(motion1.getStartTime(), motion2.getStartTime());
  }
}
