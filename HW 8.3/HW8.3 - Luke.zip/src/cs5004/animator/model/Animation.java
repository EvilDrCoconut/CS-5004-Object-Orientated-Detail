package cs5004.animator.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation of animation class.
 */
public interface Animation {

  /**
   * Sets the canvas on in which animations will be bound.
   *
   * @param x      x coordinate of canvas
   * @param y      y coordinate of canvas
   * @param width  width of canvas
   * @param height height of canvas
   */
  void addCanvas(int x, int y, int width, int height);

  /**
   * Adds a Transformation object to the array list.
   * <p>
   * //   * @param transformation object of a Shape transformation.
   */
  void addTransformation();

  /**
   * Add Shape object to the shape hash map with shape's id as the key and shape object as the
   * value.
   *
   * @param id    unique id of shape
   * @param shape shape object
   */
  void addShape(String id, Shape shape);

  /**
   * Retrieves a shape object (hash map value) based on shape's unique id (hash map key).
   *
   * @param id unique shape id
   * @return shape object
   */
  Shape getShape(String id);

  /**
   * Retrieves the shape hash map that is used by the AnimationImpl class.
   *
   * @return shape hash map object
   */
  HashMap<String, Shape> retHashmap();

  /**
   * Returns an item in the Transformation array list.
   *
   * @param id String ID to identify the object.
   * @return a transformation object based on the entered ID.
   */
  Transformation getTransformation(String id);

  /**
   * Replaces a shape object in the shape hash map.
   *
   * @param id    unique shape ID
   * @param shape object to replace shape object already in hash map
   */
  void replace(String id, Shape shape);

  /**
   * String that reflects all the transformation by citing beginning property and transformation
   * result property.
   *
   * @return a string detailing the transformation of each object that has occurred
   */
  String getState1();

  /**
   * Sorts the transformation object list by the end times of the transformation objects.
   */
//  void endTimeSort();

  /**
   * Retrieves transformation list from AnimationImpl class.
   *
   * @return transformation list
   */
  List<Transformation> retList();


  /**
   * Gets the end time of the object in the most previous transformation.
   *
   * @return previous transformation object's end time
   */
  int getFinalTime();

  /**
   * Gets canvas object.
   *
   * @return canvas object
   */
  Canvas retCanvas();

  /**
   * Retrieves the shape objects at the requested animation from.
   *
   * @param frame number of frame
   * @param speed speed of animation
   * @return shape object at frame
   */
  Map<String, Shape> getShapesInCurrentFrame(int frame, int speed);

  List<Shape> getShapesInFrame(int frame);
}
