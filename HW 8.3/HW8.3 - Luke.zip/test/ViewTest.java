
import org.junit.Test;

import java.io.IOException;

import cs5004.animator.view.EasyAnimator;

import static org.junit.Assert.assertEquals;

/**
 * Test to make sure main is sending wanted files to proper outs.
 */
public class ViewTest {

  /**
   * Test to show that not giving an out sends it to System.out
   *
   * @throws IOException if no proper input file is found.
   */
  @Test
  public void testFirst() throws IOException {
    String[] args = {"-in", "Startcode\\code\\smalldemo.txt", "-speed", "3", "-view", "text"};
    EasyAnimator.main(args);
    String test = "text";
    assertEquals("text", test);
  }

  @Test
  public void testFirst_Secondhalf() throws IOException {
    String[] args = {"-in", "Startcode\\code\\smalldemo.txt", "-speed", "3", "-view", "text", "-out", "resources\\small_demo.text"};
    EasyAnimator.main(args);
    String test = "text";
    assertEquals("text", test);
  }

  @Test
  public void testSecond() throws IOException{
    String[] args = {"-in", "Startcode\\code\\smalldemo.txt", "-speed", "3", "-view", "svg"};
    EasyAnimator.main(args);
    String test = "test";
    assertEquals("test", test);
  }

  /**
   * Test to show text files properly exports out to txt file.
   *
   * @throws IOException if no proper input file is found.
   */
  @Test
  public void testThird() throws IOException {
    String[] args = {"-in", "Startcode\\code\\smalldemo.txt", "-speed", "3", "-view", "svg", ""
            + "-out", "resources\\small_demo.svg"};
    EasyAnimator.main(args);
    String test = "test";
    assertEquals("test", test);
  }

  @Test
  public void testFourth() throws IOException {
    String[] args = {"-in", "Startcode\\code\\toh-3.txt", "-speed", "3", "-view", "svg", ""
            + "-out", "resources\\toh-at-20.svg"};
    EasyAnimator.main(args);
    String test = "test";
    assertEquals("test", test);
  }

  @Test
  public void testFifth() throws IOException {
    String[] args = {"-in", "Startcode\\code\\big-bang-big-crunch.txt", "-speed", "3", "-view", "svg", ""
            + "-out", "resources\\big-bang-big-crunch.svg"};
    EasyAnimator.main(args);
    String test = "test";
    assertEquals("test", test);
  }
}
